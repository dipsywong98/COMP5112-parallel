/**
 * Name:
 * Student id:
 * ITSC email:
*/

#include "mpi_smith_waterman.h"

/*
 *  You can add helper functions and variables as you wish.
 */

int smith_waterman(int my_rank, int p, MPI_Comm comm, char *a, char *b, int a_len, int b_len) {
    /*
     *  Please fill in your codes here.
     */
    return 0;
}
