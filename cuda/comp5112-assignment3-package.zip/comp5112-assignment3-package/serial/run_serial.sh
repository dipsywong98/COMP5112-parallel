g++ -std=c++11 main.cpp serial_smith_waterman.cpp -o serial_smith_waterman
./serial_smith_waterman ../datasets/4k.in
